var express = require('express'); //require express server
var router = express.Router(); // create Router file

/* GET home page. *//*
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});*/




/*
// ++++++++++ Example 1 +++++++++++++++
// respond to a get request under the myFirst Routes page
// '/' <-- takes the parameter of where to find this route, in this case the current directory
// function(req, res) <-- takes a anyomonys function with parameters request object and response object
router.get('/', function(req, res) {
		//res.send // used to pass result variable back to requested user from get request
		// res.render // used to render a html page from a template to the user
		

		//res.send('okay sent some test text'); // can also be used to send http number codes, json files, and more
		//res.send({usersToSend : ["John ","Doe"]}); // sending json example
		

		// render a view from the template myFirstRoutesView.hjs in the the views page
		// render the view with the json varibales passed in the 2nd variable
		jsonVarToSend = {
				title: 'My First Route: How To Title',
				user: "John Doe",
				age: 22,	
			}
		res.render('myFirstRoutesView', jsonVarToSend );
	}
);
// ++++++++++ end Example 1 +++++++++++++++
*/

//--------- Example 2 -------------
// example to respond to get api with variable passed
router.get('/', function(req, res){
	// to test the get send some variables test below url
	// localhost:5000/myfirstRoute?first=John&last=Doe&age=33
	console.log(req.query); // can use query to access parameters
	res.send(req.query); 
						

	}


);
//--------- End Example 2 -------------



/*
// if you want to respond to an api call than use post
router.post('/', function(req, res){
	req.query.var_name

	}


);*/


// we export the router file to be returned to the requested user
module.exports = router; //the return value of this entire file

